pyjulius
========
Python module to connect to a julius module server
`Julius <http://julius.sourceforge.jp/en/>`_ is a speech recognition software

* `Project page <https://github.com/Diaoul/wunderground>`_
